/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Booking;

import java.io.IOException;
import java.util.Date;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author PC 48
 */
@WebServlet(name = "BookingServlet", urlPatterns = {"/Booking/BookingServlet"})
public class BookingServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            String theCommand = request.getParameter("command");
            if (theCommand == null) {
                theCommand = "LIST";
            }
            switch (theCommand) {
                case "LIST":
                    listBooking(request, response);
                    break;
                case "ADD":
                    addBooking(request, response);
                    break;
                case "LOAD":
                    loadBooking(request, response);
                    break;
                case "UPDATE":
                    updateBooking(request, response);
                    break;
                case "DELETE":
                    deleteBooking(request, response);
                    break;
                default:
                    listBooking(request, response);
            }
        } catch (Exception ex) {
            Logger.getLogger(BookingServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void listBooking(HttpServletRequest request, HttpServletResponse response) throws Exception {
        BookingDAO bookingDao = new BookingDAO();
        List<Booking> allBooking = bookingDao.retrieveAllBooking();
        request.setAttribute("theBooking", allBooking);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/Booking/process-view-booking.jsp");
        dispatcher.forward(request, response);
    }

    private void addBooking(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String club_name = request.getParameter("club_name");
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-mm-dd");
        SimpleDateFormat sdfTime = new SimpleDateFormat("hh:mm");
        Date requestDate = sdfDate.parse(request.getParameter("requestDate"));
        System.out.println(requestDate);
        Date requestTime = sdfTime.parse(request.getParameter("requestTime"));
        Time sqlrequestTime = new Time(requestTime.getTime());
        String detail_room = request.getParameter("detail_room");
        String detail_program = request.getParameter("prog_detail");

        Booking booking = new Booking();
        booking.setClub_name(club_name);
        booking.setRequestDate(requestDate);
        booking.setRequestTime(sqlrequestTime);
        booking.setDetail_room(detail_room);
        booking.setDetail_program(detail_program);

        System.out.print("In here");

        BookingDAO bookingDao = new BookingDAO();
        int result = bookingDao.addBooking(booking);
        if (result > 0) {
            request.setAttribute("theMessage", "Success Add Booking");
            listBooking(request, response);
        }
    }

    private void loadBooking(HttpServletRequest request, HttpServletResponse response) throws Exception {
        int theBookingId = Integer.parseInt(request.getParameter("roomid"));
        BookingDAO bookingDao = new BookingDAO();
        Booking theBooking = bookingDao.retrieveOneBooking(theBookingId);

        request.setAttribute("theBooking", theBooking);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/Booking/process-update-booking.jsp");

        dispatcher.forward(request, response);
    }

    private void updateBooking(HttpServletRequest request, HttpServletResponse response) throws Exception {
        int roomid = Integer.parseInt(request.getParameter("hidid"));
        System.out.println(roomid);
        String club_name = request.getParameter("club_name");
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-mm-dd");
        SimpleDateFormat sdfTime = new SimpleDateFormat("hh:mm");
        Date requestDate = sdfDate.parse(request.getParameter("requestDate"));
        System.out.println(requestDate);
        Date requestTime = sdfTime.parse(request.getParameter("requestTime"));
        Time sqlrequestTime = new Time(requestTime.getTime());
        String detail_room = request.getParameter("detail_room");
        String detail_program = request.getParameter("prog_detail");
        String status = request.getParameter("status");

        BookingDAO bookingDao = new BookingDAO();
        Booking booking = new Booking();

        booking.setRoomid(roomid);
        booking.setClub_name(club_name);
        booking.setRequestDate(requestDate);
        booking.setRequestTime(sqlrequestTime);
        booking.setDetail_room(detail_room);
        booking.setDetail_program(detail_program);
        booking.setStatus(status);

        int result = bookingDao.updateBooking(booking);

        if (result > 0) {
            request.setAttribute("theMessage", "Success Update Booking");
            listBooking(request, response);
        } else {
            listBooking(request, response);
        }
    }

    private void deleteBooking(HttpServletRequest request, HttpServletResponse response) throws Exception {
        int roomid = Integer.parseInt(request.getParameter("roomid"));
        BookingDAO bookingDao = new BookingDAO();
        int result = bookingDao.deleteBooking(roomid);
        if (result > 0) {
            request.setAttribute("theMessage", "Success Delete Booking");
            listBooking(request, response);
        } else {
            listBooking(request, response);
        }
    }
}
