/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Booking;

import Account.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

/**
 *
 * @author User
 */
public class BookingDAO {

    private final Connection connection;
    private int result;

    public BookingDAO() {
        connection = DBConnection.getConnection();
    }

    public int addBooking(Booking booking) {
        try {
            String mySqlQuery = "INSERT INTO booking (club_name, requestDate, requestTime, detail_room, detail_program, status) VALUES (?,  ?, ?, ?, ?, ?)";
            PreparedStatement myPs = connection.prepareStatement(mySqlQuery);
            myPs.setString(1, booking.getClub_name());
            myPs.setDate(2, (new Date(booking.getRequestDate().getTime())));
            myPs.setTime(3, booking.getRequestTime());
            myPs.setString(4, booking.getDetail_room());
            myPs.setString(5, booking.getDetail_program());
            myPs.setString(6, "PENDING");
            result = myPs.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }

    public List<Booking> retrieveAllBooking() {
        List<Booking> bookingAll = new ArrayList<Booking>();
        Booking booking;

        try {
            Statement myStatement = connection.createStatement();
            String myQuery = "SELECT * FROM booking";
            ResultSet myRs = myStatement.executeQuery(myQuery);
            while (myRs.next()) {
                booking = new Booking();
                booking.setRoomid(myRs.getInt(1));
                booking.setClub_name(myRs.getString(2));
                booking.setRequestDate(myRs.getDate(3));
                booking.setRequestTime(myRs.getTime(4));
                booking.setDetail_room(myRs.getString(5));
                booking.setDetail_program(myRs.getString(6));
                booking.setStatus(myRs.getString(7));
                bookingAll.add(booking);
            }
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return bookingAll;
    }

    public Booking retrieveOneBooking(int roomid) {
        Booking booking = new Booking();
        try {
            Statement myStatement = connection.createStatement();
            String myQuery = "SELECT * FROM booking WHERE roomid=" + roomid;
            ResultSet myRs = myStatement.executeQuery(myQuery);
            while (myRs.next()) {
                booking.setRoomid(myRs.getInt(1));
                booking.setClub_name(myRs.getString(2));
                booking.setRequestDate(myRs.getDate(3));
                booking.setRequestTime(myRs.getTime(4));
                booking.setDetail_room(myRs.getString(5));
                booking.setDetail_program(myRs.getString(6));
                booking.setStatus(myRs.getString(7));
            }
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return booking;
    }

    public int updateBooking(Booking booking) {
        try {
            String mySqlQuery = "UPDATE booking SET club_name=?, requestDate=?, requestTime=?, detail_room=?, detail_program=?, status=? WHERE roomid=?";
            PreparedStatement myPs = connection.prepareStatement(mySqlQuery);
            myPs.setString(1, booking.getClub_name());
            myPs.setDate(2, new Date(booking.getRequestDate().getTime()));
            myPs.setTime(3, booking.getRequestTime());
            myPs.setString(4, booking.getDetail_room());
            myPs.setString(5, booking.getDetail_program());
            myPs.setString(6, booking.getStatus());
            myPs.setInt(7, booking.getRoomid());
            result = myPs.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }

    public int deleteBooking(int roomid) {
        try {
            String mySqlQuery = "DELETE FROM booking WHERE roomid=?";
            PreparedStatement myPs = connection.prepareStatement(mySqlQuery);
            myPs.setInt(1, roomid);
            result = myPs.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }
}
