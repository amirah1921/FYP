/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Account;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author User
 */
@WebServlet(name = "RegisterServlet", urlPatterns = {"/Account/RegisterServlet"})
public class RegisterServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            String theCommand = request.getParameter("command");
            if (theCommand == null) {
                theCommand = "LIST";
            }
            switch (theCommand) {
                case "ADD":
                    addRegister(request, response);
                    break;
                case "LOAD":
                    loadRegister(request, response);
                    break;
                case "UPDATE":
                    updateRegister(request, response);
                    break;
                case "LOGIN":
                    login(request, response);
                    break;
//                default:
//                    listRegister(request, response);
            }
        } catch (Exception ex) {
            Logger.getLogger(RegisterServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void listRegister(HttpServletRequest request, HttpServletResponse response) throws Exception {
        RegisterDAO registerDao = new RegisterDAO();
        List<Register> allRegister = registerDao.retrieveAllRegister();
        request.setAttribute("register", allRegister);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/register/process-view-register.jsp");
        dispatcher.forward(request, response);
    }

    private void addRegister(HttpServletRequest request, HttpServletResponse response) throws Exception {
//        int userid = Integer.parseInt(request.getParameter("userid"));
        PrintWriter out = response.getWriter();
        String full_name = request.getParameter("full_name");
        long ic_number = Long.parseLong(request.getParameter("ic_number"));
        String club_name = request.getParameter("club_name");
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        int role = Integer.parseInt(request.getParameter("role"));

        Register register = new Register();
//        register.setUserid(userid);
        register.setFull_name(full_name);
        register.setIc_number(ic_number);
        register.setClub_name(club_name);
        register.setUsername(username);
        register.setEmail(email);
        register.setPassword(password);
        register.setRole(role);

        RegisterDAO registerDao = new RegisterDAO();
        int result = registerDao.addRegister(register);
        if (result > 0) {
//            request.setAttribute("currentuser", register);
//            request.setAttribute("theMessage", "Success Update Account");
            out.println("<script type='text/javascript'>");
            out.println("alert('Success Register Account.');");
            out.println("window.location.href='../Admin/Awebpage.jsp';");
            out.println("</script>");
        }
    }

    private void loadRegister(HttpServletRequest request, HttpServletResponse response) throws Exception {
        int userid = Integer.parseInt(request.getParameter("userid"));
        RegisterDAO registerDao = new RegisterDAO();
        Register register = registerDao.retrieveOneRegister(userid);
        request.setAttribute("currentuser", register);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/Account/updateProfile.jsp");
        dispatcher.forward(request, response);
    }

    private void updateRegister(HttpServletRequest request, HttpServletResponse response) throws Exception {
        PrintWriter out = response.getWriter();
        int userid = Integer.parseInt(request.getParameter("userid"));
        String full_name = request.getParameter("full_name");
        long ic_number = Long.parseLong(request.getParameter("ic_number"));
        String club_name = request.getParameter("club_name");
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        int role = Integer.parseInt(request.getParameter("role"));

        Register register = new Register();
        RegisterDAO registerDao = new RegisterDAO();

        register.setUserid(userid);
        register.setFull_name(full_name);
        register.setIc_number(ic_number);
        register.setClub_name(club_name);
        register.setUsername(username);
        register.setEmail(email);
        register.setPassword(password);
        register.setRole(role);

        int result = registerDao.updateRegister(register);
        if (result > 0) {
//            request.setAttribute("currentuser", register);
//            request.setAttribute("theMessage", "Success Update Account");
            out.println("<script type='text/javascript'>");
            out.println("alert('Success Update Account! You will be logged out to refresh the account details.');");
            out.println("window.location.href='../login/Login.jsp';");
            out.println("</script>");
//            RequestDispatcher dispatcher = request.getRequestDispatcher("/login/Login.jsp");
//            dispatcher.forward(request, response);
        }
    }

    private void login(HttpServletRequest request, HttpServletResponse response) throws Exception {
        HttpSession session = request.getSession();
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        Register register;
        RegisterDAO registerDao = new RegisterDAO();

        //user=register
        register = registerDao.authenticateUserWithEmailandPassword(email, password);
        request.setAttribute("currentuser", register);

        if (register.getPassword() == null) {
            RequestDispatcher dispatcher = request.getRequestDispatcher("/login/Login.jsp");
            dispatcher.forward(request, response);

        } else {
            request.getSession().setAttribute("register", register);
            if (register.getRole() == 1) {
                RequestDispatcher dispatcher = request.getRequestDispatcher("/Admin/Awebpage.jsp");//Ubah page ikut user
                dispatcher.forward(request, response);
            } else if (register.getRole() == 2) {
                RequestDispatcher dispatcher = request.getRequestDispatcher("/MPP/Mwebpage.jsp");
                dispatcher.forward(request, response);
            } else if (register.getRole() == 3) {
                RequestDispatcher dispatcher = request.getRequestDispatcher("/PresidentClub/Pwebpage.jsp");
                dispatcher.forward(request, response);
            } else if ((register.getRole() == 4)) {
                RequestDispatcher dispatcher = request.getRequestDispatcher("/Student/Swebpage.jsp");
                dispatcher.forward(request, response);
            }

        }
    }
}
