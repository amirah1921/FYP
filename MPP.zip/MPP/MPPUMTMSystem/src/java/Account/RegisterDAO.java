/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Account;

import java.sql.*;
import java.util.*;
import Account.DBConnection;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author PC 48
 */
public class RegisterDAO {

    private final Connection connection;
    private int result;

    public RegisterDAO() {
        connection = DBConnection.getConnection();
    }

    public int addRegister(Register register) {
        try {
            String mySqlQuery = "INSERT INTO user (full_name, ic_number, club_name, username, email, password, role) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement myPs = connection.prepareStatement(mySqlQuery);
            myPs.setString(1, register.getFull_name());
            myPs.setLong(2, register.getIc_number());
            myPs.setString(3, register.getClub_name());
            myPs.setString(4, register.getUsername());
            myPs.setString(5, register.getEmail());
            myPs.setString(6, register.getPassword());
            myPs.setInt(7, register.getRole());
            result = myPs.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }

    /**
     *
     * @return
     */
    public List<Register> retrieveAllRegister() {
        List<Register> registerAll = new ArrayList<Register>();
        Register register = new Register();
        try {
            Statement myStatement = connection.createStatement();
            String myQuery = "SELECT * FROM user";
            ResultSet myRs = myStatement.executeQuery(myQuery);
            while (myRs.next()) {
                register.setUserid(myRs.getInt(1));
                register.setFull_name(myRs.getString(2));
                register.setIc_number(myRs.getLong(3));
                register.setClub_name(myRs.getString(4));
                register.setUsername(myRs.getString(5));
                register.setEmail(myRs.getString(6));
                register.setPassword(myRs.getString(7));
                register.setRole(myRs.getInt(8));
                registerAll.add(register);
            }
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return registerAll;
    }

    public Register retrieveOneRegister(String username) {
        Register register = new Register();
        try {
            Statement myStatement = connection.createStatement();
            String myQuery = "SELECT * FROM user WHERE username=" + username;
            ResultSet myRs = myStatement.executeQuery(myQuery);

            if (!myRs.next()) {
                return null;
            }
            register.setUserid(myRs.getInt(1));
            register.setFull_name(myRs.getString(2));
            register.setIc_number(myRs.getLong(3));
            register.setClub_name(myRs.getString(4));
            register.setUsername(myRs.getString(5));
            register.setEmail(myRs.getString(6));
            register.setPassword(myRs.getString(7));
            register.setRole(myRs.getInt(8));
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return register;
    }

    public int updateRegister(Register register) {
        try {
            String mySqlQuery = "UPDATE user SET full_name=?, ic_number=?, club_name=?, username=?, email=?, password=?, role=? WHERE userid=?";
            PreparedStatement myPs = connection.prepareStatement(mySqlQuery);
            myPs.setString(1, register.getFull_name());
            myPs.setLong(2, register.getIc_number());
            myPs.setString(3, register.getClub_name());
            myPs.setString(4, register.getUsername());
            myPs.setString(5, register.getEmail());
            myPs.setString(6, register.getPassword());
            myPs.setInt(7, register.getRole());
            myPs.setInt(8, register.getUserid());
            result = myPs.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }

    Register retrieveOneRegister(int userid) {
        Register register = new Register();
        try {
            Statement myStatement = connection.createStatement();
            String myQuery = "SELECT * FROM user WHERE userid=" + userid;
            ResultSet myRs = myStatement.executeQuery(myQuery);

            if (!myRs.next()) {
                return null;
            }
            register.setUserid(myRs.getInt(1));
            register.setFull_name(myRs.getString(2));
            register.setIc_number(myRs.getLong(3));
            register.setClub_name(myRs.getString(4));
            register.setUsername(myRs.getString(5));
            register.setEmail(myRs.getString(6));
            register.setPassword(myRs.getString(7));
            register.setRole(myRs.getInt(8));
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return register;
    }

    Register authenticateUserWithEmailandPassword(String email, String password) {
        Register register = new Register();
        ResultSet myRs = null;
        try {
            String mySQLQuery = "SELECT * from user where email=? and password=?";
            PreparedStatement ps = connection.prepareStatement(mySQLQuery);

            ps.setString(1, email);
            ps.setString(2, password);

            myRs = ps.executeQuery();

            // user=register
            while (myRs.next()) {
                register = new Register();
                register.setUserid(myRs.getInt(1));
                register.setFull_name(myRs.getString(2));
                register.setIc_number(myRs.getLong(3));
                register.setClub_name(myRs.getString(4));
                register.setUsername(myRs.getString(5));
                register.setEmail(myRs.getString(6));
                register.setPassword(myRs.getString(7));
                register.setRole(myRs.getInt(8));
            }
            connection.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());

        }
        return register;
    }
}
