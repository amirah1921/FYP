/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Complaint;

/**
 *
 * @author User
 */
public class Complaint {

    int complaintid;
    String email;
    String complaintissue;

    public String getComplaintissue() {
        return complaintissue;
    }

    public void setComplaintissue(String complaintissue) {
        this.complaintissue = complaintissue;
    }

    public int getComplaintid() {
        return complaintid;
    }

    public void setComplaintid(int complaintid) {
        this.complaintid = complaintid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}
