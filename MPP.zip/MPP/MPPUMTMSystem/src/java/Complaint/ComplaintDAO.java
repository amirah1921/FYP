/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Complaint;

import Account.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PC 48
 */
public class ComplaintDAO {

    private final Connection connection;
    private int result;

    public ComplaintDAO() {
        connection = DBConnection.getConnection();
    }

    public int addComplaint(Complaint complaint) {
        try {
            String mySqlQuery = "INSERT INTO complaint ( email, complaintissue) VALUES ( ?, ?)";
            PreparedStatement myPs = connection.prepareStatement(mySqlQuery);
            myPs.setString(1, complaint.getEmail());
            myPs.setString(2, complaint.getComplaintissue());
            result = myPs.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }

    public List<Complaint> retrieveAllComplaint() {
        List<Complaint> complaintAll = new ArrayList<Complaint>();
        Complaint complaint;

        try {
            Statement myStatement = connection.createStatement();
            String myQuery = "SELECT * FROM complaint";
            ResultSet myRs = myStatement.executeQuery(myQuery);
            while (myRs.next()) {
                complaint = new Complaint();
                complaint.setComplaintid(myRs.getInt(1));
                complaint.setEmail(myRs.getString(2));
                complaint.setComplaintissue(myRs.getString(3));
                complaintAll.add(complaint);
            }
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return complaintAll;
    }

    public Complaint retrieveOneComplaint(int complaintid) {
        Complaint complaint = new Complaint();
        try {
            Statement myStatement = connection.createStatement();
            String myQuery = "SELECT * FROM complaint WHERE complaintid=" + complaintid;
            ResultSet myRs = myStatement.executeQuery(myQuery);
            while (myRs.next()) {
                complaint.setComplaintid(myRs.getInt(1));
                complaint.setEmail(myRs.getString(2));
                complaint.setComplaintissue(myRs.getString(3));
            }
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return complaint;
    }

    public int updateComplaint(Complaint complaint) {
        try {
            String mySqlQuery = "UPDATE complaint SET  email=?, complaintissue=? WHERE complaintid=?";
            PreparedStatement myPs = connection.prepareStatement(mySqlQuery);
            myPs.setString(1, complaint.getEmail());
            myPs.setString(2, complaint.getComplaintissue());
            myPs.setInt(3, complaint.getComplaintid());
            result = myPs.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }

    public int deleteComplaint(int complaintid) {
        try {
            String mySqlQuery = "DELETE FROM complaint WHERE complaintid=?";
            PreparedStatement myPs = connection.prepareStatement(mySqlQuery);
            myPs.setInt(1, complaintid);
            result = myPs.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }
}
