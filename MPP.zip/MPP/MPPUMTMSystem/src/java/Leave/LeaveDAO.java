/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Leave;

import Account.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

/**
 *
 * @author User
 */
public class LeaveDAO {

    private final Connection connection;
    private int result;

    public LeaveDAO() {
        connection = DBConnection.getConnection();
    }

    public int addLeave(Leave leave) {
        try {
            String mySqlQuery = "INSERT INTO `leave`(requestDate, reason, status) VALUES(?, ?, ?)";
            PreparedStatement myPs = connection.prepareStatement(mySqlQuery);
            myPs.setDate(1, (new Date(leave.getRequestDate().getTime())));
            myPs.setString(2, leave.getReason());
            myPs.setString(3, "PENDING");
            result = myPs.executeUpdate();

        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }

    public List<Leave> retrieveAllLeave() {
        List<Leave> leaveAll = new ArrayList<Leave>();
        Leave leave;

        try {
            Statement myStatement = connection.createStatement();
            String myQuery = "SELECT * FROM `leave`";
            ResultSet myRs = myStatement.executeQuery(myQuery);
            while (myRs.next()) {
                leave = new Leave();
                leave.setLeaveid(myRs.getInt(1));
                leave.setReason(myRs.getString(2));
                leave.setRequestDate(myRs.getDate(3));
                leave.setStatus(myRs.getString(4));
                leaveAll.add(leave);
            }
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return leaveAll;
    }

    public Leave retrieveOneLeave(int leaveid) {
        Leave leave = new Leave();
        try {
            Statement myStatement = connection.createStatement();
            String myQuery = "SELECT * FROM `leave` WHERE leaveid=" + leaveid;
            ResultSet myRs = myStatement.executeQuery(myQuery);
            while (myRs.next()) {
                leave.setLeaveid(myRs.getInt(1));
                leave.setReason(myRs.getString(2));
                leave.setRequestDate(myRs.getDate(3));
                leave.setStatus(myRs.getString(4));
            }
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return leave;
    }

    public int updateLeave(Leave leave) {
        try {
            String mySqlQuery = "UPDATE `leave` SET requestDate=?, reason=?, status=? WHERE leaveid=?";
            PreparedStatement myPs = connection.prepareStatement(mySqlQuery);
            myPs.setDate(1, new Date(leave.getRequestDate().getTime()));
            myPs.setString(2, leave.getReason());
            myPs.setString(3, leave.getStatus());
            myPs.setInt(4, leave.getLeaveid());
            result = myPs.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }

    public int deleteLeave(int leaveid) {
        try {
            String mySqlQuery = "DELETE FROM `leave` WHERE leaveid=?";
            PreparedStatement myPs = connection.prepareStatement(mySqlQuery);
            myPs.setInt(1, leaveid);
            result = myPs.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }
}
