/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Leave;

import java.io.IOException;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author PC 48
 */
@WebServlet(name = "LeaveServlet", urlPatterns = {"/Leave/LeaveServlet"})
public class LeaveServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            String theCommand = request.getParameter("command");
            if (theCommand == null) {
                theCommand = "LIST";
            }
            switch (theCommand) {
                case "LIST":
                    listLeave(request, response);
                    break;
                case "ADD":
                    addLeave(request, response);
                    break;
                case "LOAD":
                    loadLeave(request, response);
                    break;
                case "UPDATE":
                    updateLeave(request, response);
                    break;
                case "DELETE":
                    deleteLeave(request, response);
                    break;
                default:
                    listLeave(request, response);
            }
        } catch (Exception ex) {
            Logger.getLogger(LeaveServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void listLeave(HttpServletRequest request, HttpServletResponse response) throws Exception {
        LeaveDAO leaveDao = new LeaveDAO();
        List<Leave> allLeave = leaveDao.retrieveAllLeave();
        request.setAttribute("theLeave", allLeave);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/Leave/process-view-leave.jsp");
        dispatcher.forward(request, response);
    }

    private void addLeave(HttpServletRequest request, HttpServletResponse response) throws Exception {
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-mm-dd");
        Date requestDate = sdfDate.parse(request.getParameter("requestDate"));
        System.out.println(requestDate);
        String reason = request.getParameter("reason_detail");

        Leave leave = new Leave();
        leave.setRequestDate(requestDate);
        leave.setReason(reason);

        System.out.print("In here");

        LeaveDAO leaveDao = new LeaveDAO();
        int result = leaveDao.addLeave(leave);
        if (result > 0) {
            request.setAttribute("theMessage", "Success Add Leave");
            listLeave(request, response);
        }
    }

    private void loadLeave(HttpServletRequest request, HttpServletResponse response) throws Exception {
        int theLeaveId = Integer.parseInt(request.getParameter("leaveid"));
        LeaveDAO leaveDao = new LeaveDAO();
        Leave theLeave = leaveDao.retrieveOneLeave(theLeaveId);

        request.setAttribute("theLeave", theLeave);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/Leave/process-update-leave.jsp");

        dispatcher.forward(request, response);
    }

    private void updateLeave(HttpServletRequest request, HttpServletResponse response) throws Exception {
        int leaveid = Integer.parseInt(request.getParameter("hidid"));
        System.out.println(leaveid);
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-mm-dd");
        Date requestDate = sdfDate.parse(request.getParameter("requestDate"));
        System.out.println(requestDate);
        String reason = request.getParameter("reason_detail");
        String status = request.getParameter("status");

        LeaveDAO leaveDao = new LeaveDAO();
        Leave leave = new Leave();

        leave.setLeaveid(leaveid);
        leave.setRequestDate(requestDate);
        leave.setReason(reason);
        leave.setStatus(status);

        int result = leaveDao.updateLeave(leave);
        if (result > 0) {
            request.setAttribute("theMessage", "Success Update Leave");
            listLeave(request, response);
        } else {
            listLeave(request, response);
        }
    }

    private void deleteLeave(HttpServletRequest request, HttpServletResponse response) throws Exception {
        int leaveid = Integer.parseInt(request.getParameter("leaveid"));
        LeaveDAO leaveDao = new LeaveDAO();
        int result = leaveDao.deleteLeave(leaveid);
        if (result > 0) {
            request.setAttribute("theMessage", "Success Delete Leave");
            listLeave(request, response);
        } else {
            listLeave(request, response);
        }
    }
}
