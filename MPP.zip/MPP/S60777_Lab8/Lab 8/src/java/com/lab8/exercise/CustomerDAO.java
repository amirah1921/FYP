/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lab8.exercise;

import java.sql.*;
import java.util.*;

/**
 *
 * @author PC 48
 */
public class CustomerDAO {

    private final Connection connection;
    private int result;

    public CustomerDAO() {
        connection = DBConnectionExercise.getConnection();
    }

    public int add(Customer customer) {
        try {
            String mySqlQuery = "INSERT INTO customer (cus_email, cus_password, cus_name, cus_ic) VALUES (?, ?, ?, ?)";
            PreparedStatement myPs = connection.prepareStatement(mySqlQuery);
            myPs.setString(1, customer.getCus_email());
            myPs.setString(2, customer.getCus_password());
            myPs.setString(3, customer.getCus_name());
            myPs.setString(4, customer.getCus_ic());
            result = myPs.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }

    public List<Customer> retrieveAllCustomer() {
        List<Customer> allCustomer = new ArrayList<Customer>();
        Customer customer = new Customer();
        try {
            Statement myStatement = connection.createStatement();
            String myQuery = "SELECT * FROM customer";
            ResultSet myRs = myStatement.executeQuery(myQuery);
            while (myRs.next()) {
                customer.setCus_id(myRs.getInt(1));
                customer.setCus_email(myRs.getString(2));
                customer.setCus_password(myRs.getString(3));
                customer.setCus_name(myRs.getString(4));
                customer.setCus_ic(myRs.getString(5));
                allCustomer.add(customer);
            }
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return allCustomer;
    }

    public Customer retrieveOneCustomer(int id) {
        Customer customer = new Customer();
        try {
            Statement myStatement = connection.createStatement();
            String myQuery = "SELECT * FROM customer WHERE cus_id=" + id; //指定条件 不需要while
            ResultSet myRs = myStatement.executeQuery(myQuery);

            if (!myRs.next()) {
                return null;
            }
            customer.setCus_id(myRs.getInt(1));
            customer.setCus_email(myRs.getString(2));
            customer.setCus_password(myRs.getString(3));
            customer.setCus_name(myRs.getString(4));
            customer.setCus_ic(myRs.getString(5));
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return customer;
    }

    public Customer retrieveOneCustomer(String email) {
        Customer customer = new Customer();
        try {
            Statement myStatement = connection.createStatement();
            String myQuery = "SELECT * FROM customer WHERE cus_email='" + email + "'";
            ResultSet myRs = myStatement.executeQuery(myQuery);

            if (!myRs.next()) {
                return null;
            }

            customer.setCus_id(myRs.getInt(1));
            customer.setCus_email(myRs.getString(2));
            customer.setCus_password(myRs.getString(3));
            customer.setCus_name(myRs.getString(4));
            customer.setCus_ic(myRs.getString(5));
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return customer;
    }

    public int updateCustomer(Customer customer) {
        try {
            String mySqlQuery = "UPDATE customer SET cus_email=?, cus_password=?, cus_name=?, cus_ic=? WHERE cus_id=" + customer.getCus_id();
            PreparedStatement myPs = connection.prepareStatement(mySqlQuery);
            myPs.setString(1, customer.getCus_email());
            myPs.setString(2, customer.getCus_password());
            myPs.setString(3, customer.getCus_name());
            myPs.setString(4, customer.getCus_ic());
            result = myPs.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }
}
