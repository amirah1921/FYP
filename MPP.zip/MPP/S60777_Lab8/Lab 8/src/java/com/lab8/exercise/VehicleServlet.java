/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.lab8.exercise;

import java.io.IOException;
import java.util.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Allison
 */
public class VehicleServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String command = request.getParameter("command");

        if (command == null) {
            listVehicle(request, response);
        }

        switch (command) {

            case "LIST":
                listVehicle(request, response);
                break;
            case "ADD":
                addVehicle(request, response);
                break;
            case "LOAD":
                loadVehicle(request, response);
                break;
            case "UPDATE":
                updateVehicle(request, response);
                break;
            case "DELETE":
                deleteVehicle(request, response);
                break;
            case "QUOTATION":
                quotationVehicle(request, response);
                break;
            default:
                listVehicle(request, response);
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    public void listVehicle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("cus_id"));
        VehicleDAO vehicleDao = new VehicleDAO();
        List<Vehicle> allVehicle = vehicleDao.retrieveAllVehicle(id);
        request.setAttribute("allVehicle", allVehicle);
        RequestDispatcher rd = request.getRequestDispatcher("./Exercise/vehicleList.jsp");
        rd.forward(request, response);
    }

    public void addVehicle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String plat = request.getParameter("plat");
        String type = request.getParameter("type");
        String brand = request.getParameter("brand");
        String marketprice = request.getParameter("marketprice");
        int cus_id = Integer.parseInt(request.getParameter("cus_id"));

        Vehicle vehicle = new Vehicle();
        VehicleDAO vehicleDao = new VehicleDAO();

        vehicle.setVeh_plat(plat);
        vehicle.setVeh_type(type);
        vehicle.setVeh_brand(brand);
        vehicle.setVeh_marketprice(marketprice);
        vehicle.setCus_id(cus_id);

        vehicleDao.addVehicle(vehicle);
        listVehicle(request, response);
    }

    public void loadVehicle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int vehicleId = Integer.parseInt(request.getParameter("veh_id"));
        VehicleDAO vehicleDao = new VehicleDAO();
        Vehicle vehicle = vehicleDao.retrieveOneVehicle(vehicleId);
        request.setAttribute("vehicle", vehicle);
        RequestDispatcher dispatcher = request.getRequestDispatcher("./Exercise/vehicleUpdate.jsp");
        dispatcher.forward(request, response);
    }

    public void updateVehicle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("veh_id"));
        String plat = request.getParameter("plat");
        String type = request.getParameter("type");
        String brand = request.getParameter("brand");
        String marketprice = request.getParameter("marketprice");
        int cus_id = Integer.parseInt(request.getParameter("cus_id"));

        Vehicle vehicle = new Vehicle();
        VehicleDAO vehicleDao = new VehicleDAO();

        vehicle.setVeh_id(id);
        vehicle.setVeh_plat(plat);
        vehicle.setVeh_type(type);
        vehicle.setVeh_brand(brand);
        vehicle.setVeh_marketprice(marketprice);
        vehicle.setCus_id(cus_id);

        int result = vehicleDao.updateVehicle(vehicle);
        if (result > 0) {
            request.setAttribute("theMessage", "Success Update Record");
            listVehicle(request, response);
        }
    }

    public void deleteVehicle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int vehicleId = Integer.parseInt(request.getParameter("veh_id"));
        VehicleDAO vehicleDao = new VehicleDAO();
        int result = vehicleDao.deleteVehicle(vehicleId);
        if (result > 0) {
            request.setAttribute("theMessage", "Success Delete Record");
            listVehicle(request, response);
        }
    }

    public void quotationVehicle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("cus_id"));
        VehicleDAO vehicleDao = new VehicleDAO();
        List<Vehicle> vehiclePlate = vehicleDao.insuranceQuotation(id);
        request.setAttribute("vehiclePlate", vehiclePlate);
        RequestDispatcher rd = request.getRequestDispatcher("./Exercise/insurance.jsp");
        rd.forward(request, response);
    }
}
