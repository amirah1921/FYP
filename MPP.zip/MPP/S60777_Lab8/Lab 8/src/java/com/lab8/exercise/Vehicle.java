/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lab8.exercise;

/**
 *
 * @author Allison
 */
public class Vehicle {

    private int veh_id;
    private String veh_plat;
    private String veh_type;
    private String veh_brand;
    private String veh_marketprice;
    private int cus_id;

    public int getVeh_id() {
        return veh_id;
    }

    public void setVeh_id(int veh_id) {
        this.veh_id = veh_id;
    }

    public String getVeh_plat() {
        return veh_plat;
    }

    public void setVeh_plat(String veh_plat) {
        this.veh_plat = veh_plat;
    }

    public String getVeh_type() {
        return veh_type;
    }

    public void setVeh_type(String veh_type) {
        this.veh_type = veh_type;
    }

    public String getVeh_brand() {
        return veh_brand;
    }

    public void setVeh_brand(String veh_brand) {
        this.veh_brand = veh_brand;
    }

    public String getVeh_marketprice() {
        return veh_marketprice;
    }

    public void setVeh_marketprice(String veh_marketprice) {
        this.veh_marketprice = veh_marketprice;
    }

    public int getCus_id() {
        return cus_id;
    }

    public void setCus_id(int cus_id) {
        this.cus_id = cus_id;
    }

}
