/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lab8.exercise;

import java.sql.*;
import java.util.*;

/**
 *
 * @author Allison
 */
public class VehicleDAO {

    private final Connection connection;
    private int result;

    public VehicleDAO() {
        connection = DBConnectionExercise.getConnection();
    }

    public int addVehicle(Vehicle vehicle) {
        try {
            String insertQry = "INSERT INTO vehicle (veh_plate, veh_type, veh_brand, veh_marketprice, cus_id) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = connection.prepareStatement(insertQry);
            ps.setString(1, vehicle.getVeh_plat());
            ps.setString(2, vehicle.getVeh_type());
            ps.setString(3, vehicle.getVeh_brand());
            ps.setString(4, vehicle.getVeh_marketprice());
            ps.setInt(5, vehicle.getCus_id());
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }

    public List<Vehicle> retrieveAllVehicle(int cus_id) {
        List<Vehicle> allVehicle = new ArrayList<Vehicle>();
        try {
            Statement myStatement = connection.createStatement();
            String retrieveQry = "SELECT * FROM vehicle WHERE cus_id=" + cus_id;
            ResultSet rs = myStatement.executeQuery(retrieveQry);

            while (rs.next()) {
                Vehicle vehicle = new Vehicle();

                vehicle.setVeh_id(rs.getInt(1));
                vehicle.setVeh_plat(rs.getString(2));
                vehicle.setVeh_type(rs.getString(3));
                vehicle.setVeh_brand(rs.getString(4));
                vehicle.setVeh_marketprice(rs.getString(5));
                vehicle.setCus_id(rs.getInt(6));
                allVehicle.add(vehicle);
            }

        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return allVehicle;
    }

    public Vehicle retrieveOneVehicle(int vehicleId) {
        Vehicle vehicle = new Vehicle();
        try {
            Statement s = connection.createStatement();
            String retrieveQry = "SELECT * FROM vehicle WHERE veh_id=" + vehicleId;
            ResultSet rs = s.executeQuery(retrieveQry);
            while (rs.next()) {
                vehicle.setVeh_id(rs.getInt(1));
                vehicle.setVeh_plat(rs.getString(2));
                vehicle.setVeh_type(rs.getString(3));
                vehicle.setVeh_brand(rs.getString(4));
                vehicle.setVeh_marketprice(rs.getString(5));
                vehicle.setCus_id(rs.getInt(6));
            }
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return vehicle;
    }

    public int updateVehicle(Vehicle vehicle) {
        try {
            String updateQry = "UPDATE vehicle SET veh_plate=?, veh_type=?, veh_brand=?, veh_marketprice=? WHERE veh_id=?";
            PreparedStatement ps = connection.prepareStatement(updateQry);
            ps.setString(1, vehicle.getVeh_plat());
            ps.setString(2, vehicle.getVeh_type());
            ps.setString(3, vehicle.getVeh_brand());
            ps.setString(4, vehicle.getVeh_marketprice());
            ps.setInt(5, vehicle.getVeh_id());

            result = ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }

    public int deleteVehicle(int vehicleId) {
        try {
            String deleteQry = "DELETE FROM vehicle WHERE veh_id=?";
            PreparedStatement ps = connection.prepareStatement(deleteQry);
            ps.setInt(1, vehicleId);
            result = ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }

    public List<Vehicle> insuranceQuotation(int cus_id) {
        List<Vehicle> allVehiclePlate = new ArrayList<>();

        try {
            Statement s = connection.createStatement();
            String retrieveQry = "SELECT veh_plate, veh_marketprice FROM vehicle WHERE cus_id=" + cus_id;
            ResultSet rs = s.executeQuery(retrieveQry);

            while (rs.next()) {
                Vehicle vehicle = new Vehicle();
                vehicle.setVeh_plat(rs.getString(1));
                vehicle.setVeh_marketprice(rs.getString(2));
                allVehiclePlate.add(vehicle);
            }

        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return allVehiclePlate;
    }
}
