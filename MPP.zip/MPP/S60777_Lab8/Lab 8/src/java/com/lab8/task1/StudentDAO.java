/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lab8.task1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PC 48
 */
public class StudentDAO {

    private final Connection connection;
    private int result;

    public StudentDAO() {
        connection = DBConnection.getConnection();
    }

    public int addStudent(Student student) {
        try {
            String mySqlQuery = "INSERT INTO student (stud_matric, stud_name) VALUES (?, ?)";
            PreparedStatement myPs = connection.prepareStatement(mySqlQuery);
            myPs.setString(1, student.getMatric());
            myPs.setString(2, student.getName());
            result = myPs.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }

    public List<Student> retrieveAllStudent() {
        List<Student> studentAll = new ArrayList<Student>();
        Student student;

        try {
            Statement myStatement = connection.createStatement();
            String myQuery = "SELECT * FROM student";
            ResultSet myRs = myStatement.executeQuery(myQuery);
            while (myRs.next()) {
                student = new Student();
                student.setId(myRs.getInt(1));
                student.setMatric(myRs.getString(2));
                student.setName(myRs.getString(3));
                studentAll.add(student);
            }
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return studentAll;
    }

    public Student retrieveOneStudent(int studentId) {
        Student student = new Student();
        try {
            Statement myStatement = connection.createStatement();
            String myQuery = "SELECT * FROM student WHERE stud_id=" + studentId;
            ResultSet myRs = myStatement.executeQuery(myQuery);
            while (myRs.next()) {
                student.setId(myRs.getInt(1));
                student.setMatric(myRs.getString(2));
                student.setName(myRs.getString(3));
            }
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return student;
    }

    public int updateStudent(Student student) {
        try {
            String mySqlQuery = "UPDATE student SET stud_matric=?, stud_name=? WHERE stud_id=?";
            PreparedStatement myPs = connection.prepareStatement(mySqlQuery);
            myPs.setString(1, student.getMatric());
            myPs.setString(2, student.getName());
            myPs.setInt(3, student.getId());
            result = myPs.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }

    public int deleteStudent(int studentId) {
        try {
            String mySqlQuery = "DELETE FROM student WHERE stud_id=?";
            PreparedStatement myPs = connection.prepareStatement(mySqlQuery);
            myPs.setInt(1, studentId);
            result = myPs.executeUpdate();
        } catch (Exception e) {
            System.out.println("Exception is " + e);
        }
        return result;
    }
}
