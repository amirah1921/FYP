-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 29, 2023 at 07:35 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mpp`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `roomid` int(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `role` int(10) NOT NULL,
  `requestDate` date NOT NULL,
  `requestTime` time NOT NULL,
  `detail_room` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`roomid`, `username`, `status`, `role`, `requestDate`, `requestTime`, `detail_room`) VALUES
(4, 's89932', 'President AWAS', 3, '2023-01-25', '20:10:00', 'bilik biru'),
(5, 's59950', 'available', 3, '1970-01-01', '11:40:00', 'bilik biru'),
(6, 's59950', 'available', 3, '1970-01-01', '11:40:00', 'bilik biru'),
(7, 's59953', 'available', 3, '1970-01-01', '00:01:00', 'bilik biru'),
(11, 's89932', 'available', 3, '1970-01-01', '14:17:00', 'bilik biru'),
(12, 's89933', 'available', 3, '2023-01-26', '11:19:00', 'bilik biru'),
(13, 's59950', 'available', 3, '2023-01-30', '00:22:00', 'bilik biru'),
(16, 's59950', 'Timbalan President AWAS', 3, '2023-01-25', '18:13:00', 'bilik biru');

-- --------------------------------------------------------

--
-- Table structure for table `confession`
--

CREATE TABLE `confession` (
  `confessid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `confess` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `confession`
--

INSERT INTO `confession` (`confessid`, `username`, `status`, `confess`) VALUES
(2, 's89932', 'hu', 'hi'),
(7, 's59950', 'available', 'here'),
(11, 's59950', 'available', 'here'),
(12, 's59950', 'available', 'here'),
(13, 's59950', 'technical', 'pa system unfunction.'),
(14, 's59950', 'available', 'here'),
(15, 's59950', 'available', 'here'),
(19, 's59950', 'available', 'here'),
(20, 's59950', 'available', 'here'),
(21, 's59950', 'available', 'here'),
(22, 's59950', 'club', 'here'),
(28, 's59950', 'club', 'here'),
(29, 's59950', 'club', 'hi'),
(30, 's59950', 'club', 'hi'),
(31, 's59950', 'available', 'here'),
(32, 's59950', 'available', 'here'),
(33, 's59950', 'available', 'here'),
(34, 's59950', 'available', 'here'),
(35, 's59950', 'available', 'here'),
(36, 's59950', 'available', 'here');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `ic_number` bigint(20) NOT NULL,
  `matric_no` varchar(20) NOT NULL,
  `program_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `full_name`, `ic_number`, `matric_no`, `program_name`, `username`, `email`, `password`, `role`) VALUES
(1, 'nira', 32, 'S59950', 'GPSNT', 'S99505', 's59950@ocean.umt.edu.my', '1234', 3),
(7, 'syafira', 10219140032, 's67789', 'AWAS', 's89932', 's59950@ocean.umt.edu.my', '1234', 3),
(8, 'eira', 10219140032, 's59950', 'GPS', 's59950', 's59950@ocean.umt.edu.my', '1234', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`roomid`);

--
-- Indexes for table `confession`
--
ALTER TABLE `confession`
  ADD PRIMARY KEY (`confessid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `roomid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `confession`
--
ALTER TABLE `confession`
  MODIFY `confessid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
